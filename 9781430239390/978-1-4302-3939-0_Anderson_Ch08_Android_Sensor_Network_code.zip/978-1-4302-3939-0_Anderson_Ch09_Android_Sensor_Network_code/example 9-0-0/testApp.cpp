//Example 9.0-0 testApp.cpp part 1 of 7
#include "testApp.h"
void testApp::setup(){
  printf ("Start \n");
  serial.setup("/dev/ttyUSB0", 115200); // change to match where the Arduino is connected
  for (int i = 0; i < 256; i++){
    graph[i] = 127 + (100 * sin((1*(PI/127))*(i-0))); // sine functions
    graph1[i] = 127 + (75 * sin((2*(PI/127))*(i-10)));  // normalized in a 256 x 256 value area
    graph2[i] = 127 + (50 * sin((3*(PI/127))*(i-40)));
  } // end data fill installation
  for (int i = 0; i < 10; i++){
    destADR[i] = 0x00;  // set the 64 bit broadcast address
  } // end address fill
  destADR[6] = 0xFF; // set network broadcast address
  destADR[7] = 0xFF;
  destADR[8] = 0xFF;
  destADR[9] = 0xFE;
  point = 0; // zero data point indicator
  counts = 0; //used to delay packet send timing
  SensorsSent [0] = false; // packet flags
  SensorsSent [1] = false;
  SensorsSent [2] = false;
  FirstPacketsent = false;
} // end testApp::setup()
//Example 9.0-0 testApp.cpp part 2 of 7
void testApp::update(){
  unsigned char DatatoSend[3] ;
  if (counts == 500){
    printf ("sensor 1 \n");
    DatatoSend[0] = 'S';
    DatatoSend[1] = '1';
    DatatoSend[2] =  point;
    DatatoSend[3] = graph[point];
    CreatePacket(DatatoSend, 4);
    WaitForReply();
    SensorsSent [0] = true;
  }
  if (counts == 1000){
    printf ("sensor 2 \n");
    DatatoSend[0] = 'S' ;
    DatatoSend[1] = '2' ;
    DatatoSend[2] =  point;
    DatatoSend[3] = graph1[point] ;
    CreatePacket(DatatoSend , 4 );
    WaitForReply();
    SensorsSent [1] = true;
  }
  if (counts == 1500){
    printf ("sensor 3 \n");
    DatatoSend[0] = 'S';
    DatatoSend[1] = '3';
    DatatoSend[2] =  point;
    DatatoSend[3] = graph2[point] ;
    CreatePacket(DatatoSend , 4 );
    WaitForReply();
    SensorsSent [2] = true;
  }
  if (SensorsSent [0] == true && SensorsSent [1] == true && SensorsSent [2] == true){
    printf ("reset counts move point \n");
    counts = 0;
    point++;
    SensorsSent [0] = false;
    SensorsSent [1] = false;
    SensorsSent [2] = false;
  }
  counts++;
  CheckForIncoming();
} // end testApp::update()
//Example 9.0-0 testApp.cpp part 3 of 7
void testApp::CheckForIncoming(){
  incomingPacketChecksum = 0;
  incomingByteLen = 0;
  if (serial.available() && 0x7E == (incomingBuffer[0] = serial.readByte())){
    printf ("Incoming packet \n");
    incomingBuffer[1] = serial.readByte(); // pull packet length
    incomingBuffer[2] = serial.readByte();
    incomingByteLen = incomingBuffer[1] + incomingBuffer[2];
    for (int i  = 3; i <= incomingByteLen + 3; i++){  // receive the rest of the packet's data
      incomingBuffer[i]  = serial.readByte();
      incomingPacketChecksum += incomingBuffer[i]; // add byte to check sum calculation
    }
    incomingPacketChecksum = (0xFF - incomingPacketChecksum);
    incomingByteLen += 3;
    if (incomingByteLen > 0 &&
      incomingPacketChecksum == incomingBuffer[incomingByteLen + 1 ] ){
      printf ("HasCorectChecksum \n");
      ReadPacket();
      serial.flush(true,true); // flush incoming and out going serial buffers
    }
    else {
      printf ("Check Sum Error\n");
      serial.flush(true,true);
      incomingByteLen = 0;
      incomingPacketChecksum = 0;
      for (int i = 0; i <= 80; i++){
       incomingBuffer[i] = 0;
      }
    } // end the error else statement
  } //end if (serial.available() && 0x7E ==...
} // end testApp::CheckForIncoming()
//Example 9.0-0 testApp.cpp part 4 of 7
void testApp::ReadPacket(){
  switch (incomingBuffer[3]){  // check packet type and preform any responses
    case 0x90:
      dataLength = incomingByteLen - 15;  // reduce to just the data length to get the data
      for (int i = 0; i <= dataLength; i++){
        incomeData [i] = incomingBuffer[i+15]; //phrase out the data form the packet
      }
      if (dataLength == 2 && incomeData[0] == 'O' && incomeData[1] == 'K'){
        printf ("OKAY\n");    // set Okay flag true when a good reply is revived
        ReplyOK = true;
     }
      if (dataLength == 3 && incomeData[0] == 'B' && incomeData[1] == 'A' &&
        incomeData[2]  == 'D' && FirstPacketsent){
        ReplyOK = false;  // make sure that the flag is false when a BAD notify is revived
        printf ("BAD\n");
        serial.writeBytes (packetBuffer, lastPacketLength); // send last known packet
        WaitForReply();  // wait again for an okay
      }
      break;
    case 0x8B:
      printf ("Transmt Responce\n");
      break;
    case 0x88:
      printf ("Comand responce %X%X \n", incomingBuffer[8] , incomingBuffer[9]);
      break;
      default: // announce unknown packet type
      printf ("error: packet type not known\n" );
  } // end switch
} //end  testApp::ReadPacket()T
//Example 9.0-0 testApp.cpp part 5 of 7
void testApp::WaitForReply(){
  printf ("Wait for reply \n");
  ReplyOK = false;
    while (ReplyOK != true){
    CheckForIncoming();
  }
} // end testApp::WaitForReply()
//Example 9.0-0 testApp.cpp part 6 of 7
void testApp::CreatePacket(unsigned char *Outdata, int length){
  printf ("creating packet\n");
  packetBuffer[17+ length] = 0;
  packetBuffer[0] = 0x7E;    //start byte
  packetBuffer[1] = 0;       // 1st length byte will be zero with current limitations
  packetBuffer[3] = 0x10;    // frame type
  packetBuffer[4] =  0;         //frame ID
  for (int i = 5; i <= 14; i++){     // add addresses
    packetBuffer[i] = destADR[i-5];
  }
  packetBuffer[15] = 0;  //set both options
  packetBuffer[16] = 0;
  for (int i = 0; i < length; i++){
    packetBuffer[i + 17] =  Outdata [i];  // add data to packet
    printf ("graph: %X\n",packetBuffer[i+17]); // print sent data to debug console
  }
  packetBuffer[2] = 14 + length;      // set the lower length byte
  for (int i = 0; i <  packetBuffer[2]; i++){ //calculate the check sum
    packetBuffer[17+ length] =  packetBuffer[17+ length] + packetBuffer[i+3];
  }
  //finish packet by adding checksum to the final position
  packetBuffer[17+ length]= 0xFF - packetBuffer[17+ length];
  serial.writeBytes (packetBuffer, (18 + length)); // send the packet
  lastPacketLength = 18 + length;  // save last packet length
  FirstPacketsent = true;  // flag that at least the first packet is sent
} // end testApp::CreatePacket
//Example 9.0-0 testApp.cpp part 7 of 7
void testApp::draw(){
  ofBackground (50,50,50);
  ofSetLineWidth (1);
  ofSetColor(0,0,0);
  for (int i = 266; i > 9; i -=32){  // draw the grid
    ofLine(10,i,266,i);
    ofLine(i,10,i,266);
  }
  for (int i = 0; i < 255; i++){ // draw the data
    ofSetLineWidth (2);
    ofSetColor(0,255,0);
    ofLine (i+10,(266 - graph[i]) , i+11 , (266 -graph [i+1]));
    ofSetColor(255,255,0);
    ofLine (i+10,(266 - graph1[i]) , i+11 , (266 -graph1 [i+1]));
    ofSetColor(0,0,255);
    ofLine (i+10,(266 - graph2[i]) , i+11 , (266 -graph2 [i+1]));
  }
  ofSetColor(255,0,0);
  ofLine (10 + point, 10, 10 + point, 266); // draw the position line
  ofSetLineWidth (1);
  } // end testApp::draw()
