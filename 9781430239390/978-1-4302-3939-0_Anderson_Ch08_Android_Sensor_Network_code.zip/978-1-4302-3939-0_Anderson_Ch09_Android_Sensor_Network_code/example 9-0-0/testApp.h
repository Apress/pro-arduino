//Example 9.0-1 testApp.h
#pragma once
#include "ofMain.h"
class testApp : public ofBaseApp{
public:
   //Variables and objects
   unsigned char graph[256], graph1[256], graph2[256];
   unsigned char point;
   int counts;
   bool SensorsSent [3];
   bool ReplyOK;
   bool FirstPacketsent;
   unsigned char incomingBuffer[80];
   unsigned char incomeData[64];
   int incomingByteLen;
   unsigned char incomingPacketChecksum;
   unsigned char destADR[10];

   unsigned char packetBuffer [80];
   int lastPacketLength;
   unsigned char dataLength;
   ofSerial serial;
   //openFrameworks specific functions
   void setup();
   void update();
   void draw();
   // Sensor network functions to handle packets
   void CheckForIncoming();
   void WaitForReply();
   void ReadPacket ();
   void CreatePacket (unsigned char*, int);
}; // end class testApp
