package pro.arduino.adksensornetwork;

public class BufferData {
	
	private byte[] Buffer;
	private int length;

	public BufferData ( byte[] Buffer , int length) {
		//this.flag = flag; char flag,
		this.Buffer = Buffer;
		this.length = length;
	}
	public byte[] getBuffer() {
		return Buffer;
	}
	public int getLength(){
		return length;
	}
	
}// end BufferData