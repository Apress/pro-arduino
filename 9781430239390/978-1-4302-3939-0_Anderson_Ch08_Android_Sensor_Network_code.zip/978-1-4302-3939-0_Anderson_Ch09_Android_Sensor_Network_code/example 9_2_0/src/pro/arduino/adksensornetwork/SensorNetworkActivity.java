package pro.arduino.adksensornetwork;
//part1

import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;
import android.graphics.Color;
import android.widget.LinearLayout;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import com.android.future.usb.*;


import android.os.Handler; // second example
import android.os.Message;
//UI componets 
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class SensorNetworkActivity extends Activity implements Runnable {
	  // ADK input and output decloration 	
	   UsbAccessory ARDUINO_ADK; // the Accesory object
	   ParcelFileDescriptor ADKstreamObj;
	   FileInputStream ReciveFromADK;
	   FileOutputStream SendtoADK;
	   // set up and logging 
	   private static final String ACTION_USB_PERMISSION = "MEGA_ADK.USB_PERMISSION";
	   private static final String TAG = "MEGA ADK"; // debug tag sent Log
	   private UsbManager UsbManagerOBJ;
	   private PendingIntent Needed_Permission;
	   private boolean IsPermissionNeeded;
		 
	 //chart variables
	   private XYMultipleSeriesDataset SensorData = new XYMultipleSeriesDataset();
	   // the  XYMultipleSeriesRenderer spans two lines in the book
	   private XYMultipleSeriesRenderer SensorRenderer = new XYMultipleSeriesRenderer();
	   private XYSeries Sensor1CurrentSeries = new XYSeries("Sensor 1");
	   private XYSeries Sensor2CurrentSeries = new XYSeries("Sensor 2");
	   private XYSeries Sensor3CurrentSeries = new XYSeries("Sensor 3");	 
	   private GraphicalView SensorChartView;
	   // chart container and other UI objects
	   private LinearLayout layout;
	   private Button buttonSync;
	   private Button ScreenClear;
	   private EditText DataFromArduino;
	   // chart control variables 
	   double[] limits = new double[] {0, 500000,-127,127}; // for chart limits
	   double x = 0; 
	   double y = 0; 
	   double xCount = 0;
	   double lastMinX = 0;
	   boolean Sync = false;;
	   
	   
	   
	// part 3
	@Override
	public void onCreate(Bundle savedInstanceState) {
	   super.onCreate(savedInstanceState);
	   setupAccessory();
	   setContentView(R.layout.main);
	   registerUIobjects();
		
	}//end onCreate	
	@Override
	public void onDestroy() {
	   unregisterReceiver(ADKReceiver);
	   super.onDestroy();
	}//end onDestroy

	@Override
	public void onPause() {
	   super.onPause();
	   closeAccessory();
	} // end onPause() 

	@Override
	public void onResume() {
	   super.onResume();
	   SetupGraph();
	    if (ReciveFromADK != null && SendtoADK != null) {
	      return;
	     } //end  if (ReciveFromADK != ...
	   UsbAccessory[] accessories = UsbManagerOBJ.getAccessoryList();
	   UsbAccessory accessory = (accessories == null ? null : accessories[0]);
	    if (accessory != null) {
	     if (UsbManagerOBJ.hasPermission(accessory)) {
	       openAccessory(accessory);
	     } //end if (UsbManagerOBJ.hasPermission(accessory))
	     else {
	      synchronized (ADKReceiver) {
	       if (IsPermissionNeeded == true) {
	         UsbManagerOBJ.requestPermission(accessory, Needed_Permission);
	         IsPermissionNeeded = false;
	       } // end  if (IsPermissionNeeded == true) 
	      } // end synchronized ADKReceiverr)
	     } // end else for  if (UsbManagerOBJ...
	     
	    }// end if (accessory != null)
	    else {
	      Log.d(TAG, "mAccessory is null");		
	    } //end else if (accessory != null)
	} //end onResume()

	//part 4
	private BroadcastReceiver ADKReceiver = new BroadcastReceiver() {
	 @Override
	 public void onReceive(Context context, Intent intent) {
	    String action = intent.getAction();
	     if (ACTION_USB_PERMISSION.equals(action) == true) {
	       synchronized (this) {
	        UsbAccessory accessory = UsbManager.getAccessory(intent);
	         if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
	           openAccessory(accessory);
	         }
	         else {
	           Log.d(TAG, "permission denied for accessory "+ accessory);
	         }
	        IsPermissionNeeded = true;
	       } //end  synchronized (this)
	     }  //end if (ACTION_USB_PERMISSION.equals...
	     else if (UsbManager.ACTION_USB_ACCESSORY_DETACHED.equals(action)) {
	       UsbAccessory accessory = UsbManager.getAccessory(intent);
	        if (accessory != null && accessory.equals(ARDUINO_ADK)) {
	          closeAccessory();
	        }
	     } //end else if (UsbManager...
	 } // end void onReceive(Context contex ...
	}; //end private BroadcastReceiver..

	@Override
	public Object onRetainNonConfigurationInstance() {
	   if (ARDUINO_ADK != null) {
	     return ARDUINO_ADK;
	   }
	   else {
	      return super.onRetainNonConfigurationInstance();
	   }
	} // end public Object  onRetainNon*...

	// part5
	private void openAccessory(UsbAccessory accessory) {
	   ADKstreamObj = UsbManagerOBJ.openAccessory(accessory);
	    if (ADKstreamObj != null) {
	      ARDUINO_ADK = accessory;
	      FileDescriptor fd = ADKstreamObj.getFileDescriptor();
	      ReciveFromADK = new FileInputStream(fd);
	      SendtoADK = new FileOutputStream(fd);
		 
	      //new
	      Thread ADKreadthread = new Thread(null, this, "ADK_Read_Thread");
	      ADKreadthread.start();
	      
		  Log.d(TAG, "accessory opened");
	    } // end if (ADKstreamObj
	    else {
	      Log.d(TAG, "accessory open fail");
	    }
	} // end void openAccessory...

	private void setupAccessory() {
	   UsbManagerOBJ = UsbManager.getInstance(this);
	   Needed_Permission = PendingIntent.getBroadcast(this, 0, new Intent(ACTION_USB_PERMISSION), 0);
	   IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
	   filter.addAction(UsbManager.ACTION_USB_ACCESSORY_DETACHED);
	   registerReceiver(ADKReceiver, filter);
	    if (getLastNonConfigurationInstance() != null) {
	    	ARDUINO_ADK = (UsbAccessory) getLastNonConfigurationInstance();
	      openAccessory(ARDUINO_ADK);
	   }
	} //End private void setupAccessory() 

	private void closeAccessory() {
	   try {
	    if (ADKstreamObj != null) {
	      ADKstreamObj.close();
	    }
	   }// end try 
	   catch (IOException e) {
		   Log.e(TAG, "IO Exception", e);
	   } 
	   finally {
	     ADKstreamObj = null;
	     ARDUINO_ADK = null;
	   } // end of all try catch finally
	}//end private void closeAccessory()

	// part 6
	private void write(byte[] send){
	   if (SendtoADK != null) {
	      try {
	        SendtoADK.write(send);
	      }
	      catch (IOException e){ 
	        Log.e(TAG, "write failed", e);
	      }
	   }//end if (SendtoADK != null)	
	}// end private void write..

	//new

	public void run() {
	int RevivedBytes  = 0;
	  
	 while (true) { // run constantly   
		 byte[] buffer = new byte[80]; // max size capable is 16384 but slows the program down
	 try {
	     RevivedBytes = ReciveFromADK.read(buffer);
	  } 
	  catch (IOException e) {
	     Log.e(TAG, "Read failed", e);
	     break; 
	  }
	  if  (RevivedBytes >= 1 ) {
	     Message MakeBufferTransferable = Message.obtain(IncomingDataHandler);
	     MakeBufferTransferable.obj = new BufferData( buffer ,RevivedBytes);
	     IncomingDataHandler.sendMessage(MakeBufferTransferable);
	  }	
	 }// end while 
	}//end public void run()()
// part 7
	
	private void registerUIobjects(){
		  buttonSync = (Button) findViewById(R.id.syncbutton); 
		  ScreenClear = (Button) findViewById(R.id.clear);    
		  DataFromArduino = (EditText)findViewById(R.id.incomingData);	   
		  layout = (LinearLayout) findViewById(R.id.chart);
		  // the next line spans two in the book 
		  SensorChartView = ChartFactory.getLineChartView(this, SensorData, 
		  SensorRenderer);
		  layout.addView(SensorChartView);
		}// end registerUIobjects
		//Example 9.2-5  the function that defines how the graph is drawn  
		public void SetupGraph(){	 
		   // set chart drawing options  
		   SensorRenderer.setAxisTitleTextSize(10);
		   SensorRenderer.setChartTitleTextSize(10);
		   SensorRenderer.setLabelsTextSize(10);
		   SensorRenderer.setLegendTextSize(10);
		   SensorRenderer.setMargins(new int[] {10, 10, 10, 0});
		   SensorRenderer.setAxesColor(Color.WHITE);
		   SensorRenderer.setShowGrid(true);
		   SensorRenderer.setYAxisMin(-127);
		   SensorRenderer.setYAxisMax(127);
		   SensorRenderer.setXAxisMin(0);
		   SensorRenderer.setXAxisMax(100);
		   SensorRenderer.setPanLimits(limits);
		   // add the three series to the multi series data set  
		   SensorData.addSeries(Sensor1CurrentSeries);
		   SensorData.addSeries(Sensor2CurrentSeries);
		   SensorData.addSeries(Sensor3CurrentSeries);
		   // set color options for the data lines to match graph openFrameworks  
		   XYSeriesRenderer Sensor1renderer = new XYSeriesRenderer();
		   Sensor1renderer.setColor(Color.GREEN);
		   XYSeriesRenderer Sensor2renderer = new XYSeriesRenderer();
		   Sensor2renderer.setColor(Color.YELLOW);
		   XYSeriesRenderer Sensor3renderer = new XYSeriesRenderer();
		   Sensor3renderer.setColor(Color.BLUE);
		   // add the sensor graph with set options to the graph.
		   SensorRenderer.addSeriesRenderer(Sensor1renderer);
		   SensorRenderer.addSeriesRenderer(Sensor2renderer);
		   SensorRenderer.addSeriesRenderer(Sensor3renderer);
		} //end SetupGraph	
		//Example 9.2-6 incoming data handler function  	
		Handler IncomingDataHandler = new Handler() {
		  @Override
		  public void handleMessage(Message msg) {
		    BufferData IncomingBuffer = (BufferData) msg.obj;
		    byte[] buffer = IncomingBuffer.getBuffer();
		    // pull and add sensor data to the graph 
		    byte sen1 = (byte) (buffer[5] - 127);
		    byte sen2 = (byte) (buffer[13] - 127);
		    byte sen3 = (byte) (buffer[21] - 127);
		    Sensor1CurrentSeries.add(xCount,  sen1 );
		    Sensor2CurrentSeries.add(xCount,  sen2 );
		    Sensor3CurrentSeries.add(xCount,  sen3 );
		    // check if a scroll is needed
		    refreshChart();
		    xCount++;
		    if (SensorChartView != null) {
		      SensorChartView.repaint();
		    }
		    // add data buffer to text box
		    String str = new String(buffer);
		    DataFromArduino.append(str);
		  }//end handleMessage(Message msg)
		};//end Handler IncomingDataHandler = new Handler()
		//Example 9.2-6 function to keep the graph  focused on the most current  data .
		private void refreshChart() {
		  // check if a shift of the graph view is needed 
		  if (xCount > SensorRenderer.getXAxisMax()) {
		    SensorRenderer.setXAxisMax(xCount);
		    SensorRenderer.setXAxisMin(++lastMinX);
		  }		    
		  SensorChartView.repaint();
		}
		//Example 9.2-7 clear screen and sync data button events 
		public void clearScreen (View v) {
		  byte[] BytestoSend = new byte[1];
		  BytestoSend[0] = 'b';
		  write(BytestoSend);
		  Sensor1CurrentSeries.clear();
		  Sensor2CurrentSeries.clear();
		  Sensor3CurrentSeries.clear();
		  xCount = 0 ;
		  lastMinX = 0 ; 
		  SensorRenderer.setYAxisMin(-127);
		  SensorRenderer.setYAxisMax(127);
		  SensorRenderer.setXAxisMin(0);
		  SensorRenderer.setXAxisMax(100);
		  Sync = false ;
		  SensorChartView.repaint();
		  DataFromArduino.setText(null);
		}//end clearScreen 

		public void SyncData(View v) {
		  if (!Sync){
		    byte[] BytestoSend = new byte[1];
		    BytestoSend[0] = 'a';
		    write(BytestoSend); //sends buffer to the ADK
		    Sync = true;
		  }
		} // end void SyncData(View v)
}