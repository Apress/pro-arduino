chapter9
========

Pro Arduino Chapter 9 Examples

* Listing 9_1-12 are for the ObjectDetecton example
* Listing 9_13-16 are for the Attiny Secret Knock example


To test if your Attiny programming worked use the AttinyBlinkAllPinsTest sketch. It blinks all the pins. Which will blink any leds you have attached.


